import type { Song } from '@/types/music'
/**
 * 播放器服务层 —— 单一事实来源
 *
 * 设计要点（见项目经验）：
 *  - 全局唯一 HTMLAudioElement 实例，禁止组件自行 new
 *  - 所有播放意图仅通过 play / pause / seek / next / prev 等方法触发
 *  - 进度、时长、播放状态由 audio 事件驱动，避免定时器漂移
 *  - 组件只与 Pinia store 响应式引用绑定，不直接操作 audio
 */
import { usePlayerStore } from '@/stores/player'

// 模块级单例 audio；preload=auto 才能在暂停时也产出缓冲进度与 canplay
const audio = new Audio()
audio.preload = 'auto'

let bound = false
/** 连续播放失败的歌曲数，整轮都失败时停止自动切歌，避免死循环 */
let failedCount = 0

function bindEvents() {
  if (bound)
    return
  bound = true

  const store = usePlayerStore()

  audio.addEventListener('loadedmetadata', () => {
    store.setDuration(audio.duration || 0)
    syncBuffered()
  })

  audio.addEventListener('progress', syncBuffered)

  audio.addEventListener('canplay', () => {
    store.setLoading(false)
    store.setCanSeek(true)
  })

  audio.addEventListener('timeupdate', () => {
    store.setCurrentTime(audio.currentTime)
  })

  audio.addEventListener('play', () => {
    store.setPlaying(true)
  })

  audio.addEventListener('pause', () => {
    store.setPlaying(false)
  })

  audio.addEventListener('ended', () => {
    store.setPlaying(false)
    handleEnded()
  })

  audio.addEventListener('waiting', () => {
    store.setLoading(true)
  })

  audio.addEventListener('playing', () => {
    store.setLoading(false)
    // 成功播放后重置失败计数
    failedCount = 0
  })

  audio.addEventListener('error', () => {
    store.setLoading(false)
    store.setPlaying(false)
    store.setCanSeek(false)
    console.warn('[player] audio error', store.currentSong?.url, audio.error)
    // 播放失败自动进入下一首
    autoNextOnError()
  })

  // 切歌：重置缓冲进度，等 canplay 后再允许拖动
  audio.addEventListener('loadstart', () => {
    store.setBuffered(0)
    store.setCanSeek(false)
  })
}

/** 同步已缓冲时长；readyState 足够时直接放开拖动 */
function syncBuffered() {
  const store = usePlayerStore()
  const ranges = audio.buffered
  store.setBuffered(ranges.length ? ranges.end(ranges.length - 1) : 0)
  if (audio.readyState >= audio.HAVE_CURRENT_DATA)
    store.setCanSeek(true)
}

function handleEnded() {
  const store = usePlayerStore()
  if (store.playMode === 'loop') {
    // 单曲循环
    audio.currentTime = 0
    audio.play().catch(() => {})
    return
  }
  // 列表顺序/随机：切到下一首
  const next = store.nextIndex()
  if (next >= 0) {
    store.setCurrentIndex(next)
    playCurrent().catch(() => {})
  }
}

/** 当前歌曲播放失败时自动切到下一首；整轮都失败则停止 */
function autoNextOnError() {
  const store = usePlayerStore()
  const total = store.playList.length
  if (total === 0)
    return

  failedCount += 1
  if (failedCount >= total) {
    failedCount = 0
    console.warn('[player] 所有歌曲均播放失败，停止自动切歌')
    return
  }

  const next = store.nextIndex()
  if (next < 0)
    return
  store.setCurrentIndex(next)
  playCurrent().catch(() => {})
}

// 确保事件只绑定一次（在应用启动时调用）
export function initPlayerService() {
  bindEvents()
  const store = usePlayerStore()
  audio.volume = store.volume
}

/** 设置音量 */
export function setVolume(v: number) {
  const store = usePlayerStore()
  store.setVolume(v)
  audio.volume = v
}

/** 播放指定歌曲（加入/替换歌单并播放） */
export async function play(song: Song, list?: Song[]) {
  const store = usePlayerStore()
  if (list) {
    const idx = list.findIndex(s => s.id === song.id)
    store.setPlayList(list, idx >= 0
      ? idx
      : 0)
  } else {
    // 如果当前歌单里已经有这首歌，直接定位
    const idx = store.playList.findIndex(s => s.id === song.id)
    if (idx >= 0) {
      store.setCurrentIndex(idx)
    } else {
      store.setPlayList([song], 0)
    }
  }
  await playCurrent()
}

/** 按索引播放当前歌单 */
export async function playByIndex(index: number) {
  const store = usePlayerStore()
  store.setCurrentIndex(index)
  await playCurrent()
}

/** 播放当前 store 中 currentSong */
async function playCurrent() {
  const store = usePlayerStore()
  const song = store.currentSong
  if (!song)
    return

  if (audio.src !== song.url) {
    store.setLoading(true)
    audio.src = song.url
  }

  try {
    await audio.play()
  } catch (err) {
    store.setPlaying(false)
    store.setLoading(false)
    console.warn('[player] play failed', err)
  }
}

/** 暂停 */
export function pause() {
  audio.pause()
}

/** 切换播放/暂停 */
export async function toggle() {
  const store = usePlayerStore()
  if (!store.currentSong)
    return
  if (store.isPlaying) {
    pause()
  } else {
    await playCurrent()
  }
}

/** 上一首 */
export async function prev() {
  const store = usePlayerStore()
  const idx = store.prevIndex()
  if (idx >= 0) {
    store.setCurrentIndex(idx)
    await playCurrent()
  }
}

/** 下一首 */
export async function next() {
  const store = usePlayerStore()
  const idx = store.nextIndex()
  if (idx >= 0) {
    store.setCurrentIndex(idx)
    await playCurrent()
  }
}

/** 跳转进度（秒） */
export function seek(seconds: number) {
  const store = usePlayerStore()
  if (!store.currentSong)
    return
  audio.currentTime = Math.max(0, Math.min(seconds, audio.duration || seconds))
  store.setCurrentTime(audio.currentTime)
}

/** 按百分比跳转 (0-100) */
export function seekByPercent(percent: number) {
  const store = usePlayerStore()
  if (!store.duration)
    return
  seek((percent / 100) * store.duration)
}

/** 销毁（SSR/卸载场景） */
export function dispose() {
  audio.pause()
  audio.removeAttribute('src')
  audio.load()
}
